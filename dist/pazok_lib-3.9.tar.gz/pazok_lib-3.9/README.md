<h1 align="center">pazok</h1>


### What is pazok?
It is a python library that contains a set of ready-made codes that enable you to create the most wonderful designs and animations on the terminal.

### Support
+ python
+ termux

### Install
Just write this code on terminal:
```shell
pip3 install pazok
```
If you want to download the developer version then write on terminal this code
```shell
pip3 install git+https://github.com/h98m/pazok
```
I don't recommend regular users to download the developer version

___

<p align="center">
<strong>For more infrmation</strong>
</p>

<p align="center">
<a href="https://github.com/h98m/pazok"><label style="display: block;"><strong>pazok</strong></label></a>
</p>

___
